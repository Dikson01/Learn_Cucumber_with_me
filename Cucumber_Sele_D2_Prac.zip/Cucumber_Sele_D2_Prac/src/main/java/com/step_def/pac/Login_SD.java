package com.step_def.pac;

import io.cucumber.java.en.*;
import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;

import org.openqa.selenium.*;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.asserts.SoftAssert;

public class Login_SD {

    WebDriver driver;

    @Given("The user must be in Edge Browser")
    public void the_user_must_be_in_edge_browser() {
        driver = new EdgeDriver();
    }

    @Given("The user must be on Sign_up page")
    public void the_user_must_be_on_sign_up_page() {
        driver.get("https://www.bookswagon.com/login?q=signup");
        driver.manage().window().maximize();
    }

    @When("Entering the {string}")
    public void entering_the_name(String name) {
        driver.findElement(By.id("ctl00_phBody_SignUp_txtName")).clear();
        driver.findElement(By.id("ctl00_phBody_SignUp_txtName")).sendKeys(name);
    }

    @When("Entering the phone no {string}")
    public void entering_the_phone_no(String phone) {
        driver.findElement(By.id("ctl00_phBody_SignUp_txtEmail")).clear();
        driver.findElement(By.id("ctl00_phBody_SignUp_txtEmail")).sendKeys(phone);
        driver.findElement(By.id("ctl00_phBody_SignUp_btnContinue")).click();
    }

    @Then("I verify the {string} of Signup")
    public void i_verify_the_status_of_signup(String status) throws InterruptedException {

        SoftAssert soft = new SoftAssert();

        // Read actual error messages if visible
        String actualNameErr = "";
        String actualPhoneErr = "";

        try {
            actualNameErr = driver.findElement(By.id("ctl00_phBody_SignUp_rfvName")).getText();
        } catch (Exception ignored) {}

        try {
            actualPhoneErr = driver.findElement(By.id("ctl00_phBody_SignUp_rfvEmail")).getText();
        } catch (Exception ignored) {}
        
        try {
        	actualPhoneErr = driver.findElement(By.xpath("//span[@id='ctl00_phBody_SignUp_revCustMobile']")).getText();
        } catch (Exception ignored) {}

        // Expected fixed messages (exactly as site shows)
        String expNameErr = "Please Enter Name";
        String expPhoneErr_I = "Invalid Mobile";
        String expPhoneErr_E = "Please Enter Mobile";

        // Evaluation using Soft Assertions
        if (status.equalsIgnoreCase("Fail")) {
        	
        	Thread.sleep(2000);
            // If name error is expected
            if (actualNameErr.length() > 0) {
                soft.assertEquals(actualNameErr, expNameErr, "Name error mismatch");
                System.out.println("Enter the correct name");
            }
            
            Thread.sleep(2000);
            // If phone error is expected
            if (actualPhoneErr.length() > 0 && actualPhoneErr.equalsIgnoreCase("Invalid Mobile")) {
                soft.assertEquals(actualPhoneErr, expPhoneErr_I, "Phone error mismatch");
                System.out.println("Enter the corrct phone no.");
            }
            
            if (actualPhoneErr.length() > 0 && actualPhoneErr.equalsIgnoreCase("Please Enter Mobile")) {
                soft.assertEquals(actualPhoneErr, expPhoneErr_E, "Phone error mismatch");
                System.out.println("Enter the phone no.");
            }

        } else if (status.equalsIgnoreCase("True")) {
            // No errors expected
            soft.assertTrue(actualNameErr.isEmpty(), "Name error should not appear for success");
            soft.assertTrue(actualPhoneErr.isEmpty(), "Phone error should not appear for success");
            System.out.println("Valid Credential");
        }

        soft.assertAll();
        driver.quit();
    }
}