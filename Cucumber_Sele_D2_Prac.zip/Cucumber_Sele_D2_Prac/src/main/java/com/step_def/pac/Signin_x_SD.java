package com.step_def.pac;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.*;

public class Signin_x_SD {
	
	WebDriver driver;
//	WebDriverWait wait;
	
	//Background:
	@Given("The user must be using Edge Browser")
	public void B_g() {
		driver = new EdgeDriver();
//		wait = new WebDriverWait();
	}
	
	//Scenario: Signup with Excel data
	@Given("The user must be on Sign up page")
	public void S1_g() {
		driver.get("https://www.bookswagon.com/login?q=signup");
		driver.manage().window().maximize();
	}
	
	@When("I read test data from Excel and execute")
	public void S1_w1() {
		System.out.println("fasd");
	}
	
}
