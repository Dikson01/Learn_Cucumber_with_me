package com.runner.pac;

import org.testng.annotations.Test;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features= {"C:\\Users\\dikson.aribam\\eclipse-workspace\\Cucumber_Sele_D2_Prac\\src\\test\\java\\com\\features\\pac\\Signin_x.feature"},
glue="com.step_def.pac",
tags="@tag2",
plugin = {"pretty",
	    "html:target/cucumber-report.html",
	    "json:target/cucumber-report.json",
	    "junit:target/cucumber-report.xml"})

@Test
public class Signin_x_run extends AbstractTestNGCucumberTests{
	

}
