package som.Sele_D4.Script;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import com.Sele.D4.Sele_D4_1;

public class Sele_D4_1_Test {
	
	WebDriver driver = new EdgeDriver();
	Sele_D4_1 sd1 = new Sele_D4_1();
	
  @Test
  public void Drag_Drop_test() throws InterruptedException {
	  sd1.init(driver);
	  sd1.Drag_Drop();
	  
	  sd1.open_Calender();
  }
  
  
}
