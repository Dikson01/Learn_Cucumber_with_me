package som.Sele_D4.Script;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import com.Sele.D4.Sele_D4_1;
import com.Sele.D4.Sele_D4_2;

public class Test_D4_2 {
	
	WebDriver driver = new EdgeDriver();
	Sele_D4_2 sd2 = new Sele_D4_2();
	
  @Test
  public void f() {
	  sd2.init(driver);
	  sd2.open();
  }
}
