package com.Sele.D4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Sele_D4_2 {
	
	WebDriver driver;
	public void init(WebDriver driver) {
		this.driver=driver;
	}
	
	public void open() {
		driver.get("https://en.wikipedia.org/wiki/India");
		driver.findElement(By.xpath("//*[@id=\"mw-content-text\"]/div[2]/p[19]/a[1]")).click();
	}
}
