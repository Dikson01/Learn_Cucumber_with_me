package com.Sele.D4;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Sele_D4_1 {
	
	
	WebDriver driver;
	public void init(WebDriver driver) {
		this.driver=driver;
	}
	
	
	//Drag and Drop
	public void Drag_Drop() throws InterruptedException {
		driver.get("https://jqueryui.com/droppable/");
		driver.switchTo().frame(0);
		
		Thread.sleep(2000);
		WebElement dragable = driver.findElement(By.xpath("//div[@id = 'draggable']//p"));
		WebElement target = driver.findElement(By.xpath("//div[@id = 'droppable']//p"));
		Thread.sleep(2000);
		new Actions(driver)
							.dragAndDrop(dragable, target)
							.perform();
	}
	
	//Open_Calender
	public void  open_Calender() throws InterruptedException {
		driver.get("https://practice-automation.com");


By tile = By.xpath("(//div[@class='wp-block-button has-custom-width wp-block-button__width-50 is-style-shadow'])[9]");

WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(tile));

// 1) Scroll via Actions (Selenium 4) — no JS used
new Actions(driver).scrollToElement(el).perform();

// 2) Wait until clickable (visible + enabled, and Selenium thinks it can be clicked)
wait.until(ExpectedConditions.elementToBeClickable(el));

// 3) Use Actions click (more “native”-like; sometimes succeeds where el.click() doesn’t)
new Actions(driver).moveToElement(el).pause(Duration.ofMillis(120)).click().perform();

		
	}
	
}
