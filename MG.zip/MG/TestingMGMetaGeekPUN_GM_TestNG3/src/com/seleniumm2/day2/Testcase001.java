package com.seleniumm2.day2;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
public class Testcase001 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		WebDriver wd = new ChromeDriver();
//		
//		wd.get("https://www.awesomeqa.com/ui");
		
		WebDriver wd = new EdgeDriver();
		wd.get("https://www.awesomeqa.com/ui");
		
		
	}

}
