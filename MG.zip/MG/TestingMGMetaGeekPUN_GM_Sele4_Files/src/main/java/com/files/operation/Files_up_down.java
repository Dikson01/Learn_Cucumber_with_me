package com.files.operation;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class Files_up_down {
	
	WebDriver driver;
	
	public void init(WebDriver driver) {
		this.driver = driver;
	}
	////*[@id="file1"]
	public void File_up() throws FileNotFoundException {
		//FileInputStream fis = new FileInputStream("./Test_Files/Test(Files)");
		
		driver.get("https://www.pdfgear.com/word-to-pdf");
		driver.findElement(By.xpath("//*[@id='file1']")).sendKeys("C:\\Users\\dikson.aribam\\eclipse-workspace\\TestingMGMetaGeekPUN_GM_Sele4_Files\\Test_Files\\Test(Files).docx");
		
		
	}
	
	public void key_Enter() {
		driver.get("https://the-internet.herokuapp.com/key_presses");
		
		driver.findElement(By.xpath("//*[@id='target']")).sendKeys(Keys.SPACE);
	}
	
}
