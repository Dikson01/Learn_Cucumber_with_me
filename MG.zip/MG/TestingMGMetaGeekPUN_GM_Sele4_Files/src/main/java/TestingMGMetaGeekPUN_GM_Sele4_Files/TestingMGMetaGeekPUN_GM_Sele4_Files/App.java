package TestingMGMetaGeekPUN_GM_Sele4_Files.TestingMGMetaGeekPUN_GM_Sele4_Files;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
