package com.Files.script;

import org.testng.annotations.Test;

import com.files.operation.Files_up_down;

import java.io.FileNotFoundException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Filies_UP_Down_test {
	
	WebDriver driver = new EdgeDriver();
	Files_up_down fud1 = new Files_up_down();
  @Test
  public void Upload_Files() throws FileNotFoundException {
	  fud1.init(driver);
	  fud1.File_up();
	  fud1.key_Enter();
  }
}
