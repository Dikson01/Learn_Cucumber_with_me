package com.ListMethods.Scripts;

import org.testng.annotations.Test;


public class Test11 {
  @Test
  public class r1 {
	  
	  public void x1() {
		  System.out.print("Hello ");
	  }
	  
	  public void x2() {
		  System.out.print("DIkson ");
	  }
  }
  
  @Test
  public void r2() {
	  System.out.println("P1");
  }

}
