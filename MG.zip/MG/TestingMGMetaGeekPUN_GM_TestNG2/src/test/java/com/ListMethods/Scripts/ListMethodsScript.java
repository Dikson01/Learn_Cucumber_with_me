package com.ListMethods.Scripts;

import java.util.List;
import java.util.Arrays;
import org.testng.annotations.Test;
import org.testng.Assert;
import com.ListMethods.Libtest.ListMethods;

//import junit.framework.Assert;

public class ListMethodsScript {
	//create object
	ListMethods obj = new ListMethods();
	
  boolean exp = true;
  Object expArr[] = {1,2,3,4,5,6};
  @Test
  public void f() {
	  List <String> test1 = Arrays.asList("Pune","Mumbai","Delhi");
	  //List <String> test2 = Arrays.asList("Pune1","Mumbai1","Delhi1");
	  
	  boolean res = obj.ArrayListTest(test1);
	  
	  System.out.print(res);
	  Assert.assertEquals(res, exp);
	  
  }
  
  @Test
  public void function2() {
	  List<Integer> arr1 = Arrays.asList(12,13,14,15,16);
	  
	  Object act[] = obj.ConvertListToArray(arr1);
	  Assert.assertEquals(act,expArr);
  }
}
