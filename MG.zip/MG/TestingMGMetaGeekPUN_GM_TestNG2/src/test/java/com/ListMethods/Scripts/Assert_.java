package com.ListMethods.Scripts;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Assert_ {
  @Test
  public void f() {
	  
	  SoftAssert softAssert = new SoftAssert();
	  
	  softAssert.assertEquals(1+5, 78, "Match failed");
	  
	  softAssert.assertFalse(435<55, " Condition check failed");
	  
//	  softAssert.assertAll();
	  System.out.println("Hello");
	  
	  
  }
  
  @Test(priority = 1)
  public void a() {
	  System.out.println("argjkb");
  }
}
