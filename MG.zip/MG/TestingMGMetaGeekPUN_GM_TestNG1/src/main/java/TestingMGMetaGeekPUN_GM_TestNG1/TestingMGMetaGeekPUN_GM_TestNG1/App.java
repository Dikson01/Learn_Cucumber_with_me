package TestingMGMetaGeekPUN_GM_TestNG1.TestingMGMetaGeekPUN_GM_TestNG1;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
