package com.TestNG.scripts;

import org.testng.annotations.Test;

public class TestMG1 {
  @Test
  public void m1() {
	  System.out.println("TestMG1 ");
  }
  
  @Test(groups = {"smoke"})
  public void m2() {
	  System.out.println("TestMG2 ");
  }
  
  @Test
  public void m3() {
	  System.out.println("TestMG3 ");
  }
  
}
