package com.TestNG.scripts;

import org.testng.annotations.Test;

public class TestNG_Grp1 {
  @Test(groups = {"smoke", "regression"})
  public void g1() {
	  System.out.println("TestG_1");
  }
  
  @Test(groups = {"regression"})
  public void g2() {
	  System.out.println("TestG_2");
  }
  
  @Test(groups = {"smoke"})
  public void g3() {
	  System.out.println("TestG_3");
  }
}
