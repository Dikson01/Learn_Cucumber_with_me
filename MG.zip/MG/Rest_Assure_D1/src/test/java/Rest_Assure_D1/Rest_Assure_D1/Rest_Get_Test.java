package Rest_Assure_D1.Rest_Assure_D1;

import org.testng.annotations.Test;

public class Rest_Get_Test {
	
	Rest_Get rg = new Rest_Get();
	
  @Test
  public void A() {
	  
  }
}
