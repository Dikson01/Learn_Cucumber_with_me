package Rest_Assure_D1.Rest_Assure_D1;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Rest_Get {
	public static String main(String args[]) throws InterruptedException {
		RestAssured.baseURI = "https://reqres.in";
		
		String Endp = "/api/users";
		
		String apiKey = "reqres-free-v1";
		
		
		Response response = RestAssured
			.given().relaxedHTTPSValidation().auth().oauth2(apiKey)
			.when()
			.get(Endp)
			.then()
			.extract()
			.response();
		int code = response.statusCode();
		System.out.println("Status Code is : " + code);
		
		String  statusLine = response.statusLine();
		System.out.println(statusLine);
		int statusCode1 = response.getStatusCode();
		String statusLine1=response.getStatusLine();
		
		String bodyData = response.getBody().asPrettyString();
		return bodyData;
//		System.out.println(bodyData);
		
		
		
	}
	
	
	
	
	
}
