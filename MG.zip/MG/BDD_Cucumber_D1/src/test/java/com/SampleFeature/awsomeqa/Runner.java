package com.SampleFeature.awsomeqa;

import org.testng.annotations.Test;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
@CucumberOptions(features= {"C:\\Users\\dikson.aribam\\eclipse-workspace\\BDD_Cucumber_D1\\src\\test\\java\\com\\SampleFeature\\awsomeqa\\feature1.feature"},
				
				glue = "com.backGround",
				tags="@tag1",
				plugin = {
				    "pretty",
				    "html:target/cucumber-report.html",
				    "json:target/cucumber-report.json"})
@Test
public class Runner extends AbstractTestNGCucumberTests {

}