package com.backGround;

import io.cucumber.java.en.*;

public class backGround_Step {

    // Background
    @Given("a global administrator exists")
    public void a_global_administrator_exists() {
        System.out.println("[Background] a global administrator exists");
        // setup preconditions if needed
    }

    // Scenario: To check I can perform addition
    @Given("I am holding the calculator")
    public void i_am_holding_the_calculator() {
        System.out.println("I am holding the calculator");
    }

    @When("I enter the first number")
    public void i_enter_the_first_number() {
        System.out.println("I enter the first number");
        // e.g., store a number; here it's just a placeholder
    }

    @And("I click on + symbol")
    public void i_click_on_plus_symbol() {
        System.out.println("I click on + symbol");
    }

    @And("I enter the second number")
    public void i_enter_the_second_number() {
        System.out.println("I enter the second number");
    }

    @Then("I must be able to view the sum of the numbers")
    public void i_must_be_able_to_view_the_sum_of_the_numbers() {
        System.out.println("I must be able to view the sum of the numbers");
        // add assertion if you maintain state
    }

    // Scenario: Validate input values
    @Given("I want to write a step with 123")
    public void i_want_to_write_a_step_with_123() {
        System.out.println("I want to write a step with 123");
    }

    @When("I check for the 456 in step")
    public void i_check_for_the_456_in_step() {
        System.out.println("I check for the 456 in step");
    }

    @Then("I verify the result is 10")
    public void i_verify_the_result_is_10() {
        System.out.println("I verify the result is 10");
        // Assert.assertEquals(actual, 10);
    }
}
	
