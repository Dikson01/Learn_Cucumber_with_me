package com.sele_day2;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
public class Sele_D2_Lib1 {
	
	WebDriver driver;
	public void init(WebDriver driver) {
		this.driver = driver;
	}
	
	public void Invoke_Page() {
		driver.get("https://awesomeqa.com/ui/index.php?route=account/login");
	}
	
	public void Log_out() {
		driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a")).click();
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/ul/li[5]/a")).click();
	}
	
	public String Perform_Login_Valid(String email, String password) throws InterruptedException {
		driver.findElement(By.xpath("//input[@id = \"input-email\"]")).sendKeys(email);
		driver.findElement(By.xpath("//input[@id = \"input-password\"]")).sendKeys(password);
		driver.findElement(By.xpath("//input[@type = \"submit\"]")).click();
		Thread.sleep(3000);
		String msg = driver.findElement(By.xpath("//div[@id = 'content']//h2[2]")).getText();
		return msg;
	}
	
	
	public String Invalid_Null_Login(String email, String password) throws InterruptedException {
		driver.findElement(By.xpath("//input[@id = \"input-email\"]")).sendKeys(email);
		driver.findElement(By.xpath("//input[@id = \"input-password\"]")).sendKeys(password);
		driver.findElement(By.xpath("//input[@type = \"submit\"]")).click();
		Thread.sleep(3000);
		String Error_msg = driver.findElement(By.xpath("//*[@id=\"account-login\"]/div[1]")).getText();
		return Error_msg;
	}
	
	public List Count_Links() throws InterruptedException {
		driver.get("https://www.amazon.in/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2F%3Ftag%3Dmsndeskabkin-21%26ref%3Dnav_ya_signin%26adgrpid%3D1329311168025487%26hvadid%3D83082265508847%26hvnetw%3Do%26hvqmt%3De%26hvbmt%3Dbe%26hvdev%3Dc%26hvlocint%3D%26hvlocphy%3D158263%26hvtargid%3Dkwd-83082829756950%3Aloc-90%26hydadcr%3D5650_2473574%26mcid%3D6233a7c588f136ff9af0c63d9f6745bc&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0");
		List <WebElement> Links = driver.findElements(By.tagName("a"));
		int LinkCounts = Links.size();
		
		Thread.sleep(2000);
		for (int i=0; i<LinkCounts; i++) {
			String Link_Name = Links.get(i).getText();
			Thread.sleep(200);
			System.out.println(Link_Name);
		}
		
		return Links;
	}
	

}
