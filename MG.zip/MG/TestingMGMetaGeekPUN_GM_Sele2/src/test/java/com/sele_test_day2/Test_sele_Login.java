package com.sele_test_day2;

import org.testng.annotations.Test;
import com.sele_day2.*;

import junit.framework.Assert;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.*;
import org.openqa.selenium.edge.EdgeDriver;

public class Test_sele_Login {
	
	WebDriver driver = new EdgeDriver();
	
	Sele_D2_Lib1 sd2l1 = new Sele_D2_Lib1();
	
	String ExpStr = "My Orders";
	String ErrStr = " Warning: Your account has exceeded allowed number of login attempts. Please try again in 1 hour.";
	List Dum_List = Arrays.asList("hfhdf","htrht","djtgj");
	
//  @Test(priority = 1)
//  public void Test1() throws InterruptedException {
//	  sd2l1.init(driver);
//	  Thread.sleep(3000);
//	  sd2l1.Invoke_Page();
//	  Thread.sleep(3000);
//	  String ActStr = sd2l1.Perform_Login_Valid("gayatrimis2@gmail.com", "gayatrimis2@gmail.com");
//	  Thread.sleep(3000);
//	  Assert.assertEquals(ExpStr, ActStr);
//	  Thread.sleep(5000);
//	  sd2l1.Log_out();
//  }
//  
//  @Test(priority = 2)
//  public void Test2() throws InterruptedException {
//	  sd2l1.init(driver);
//	  
//	  sd2l1.Invoke_Page();
//	  
//	  String Null_Val = sd2l1.Invalid_Null_Login("","");
//	  
//	  Assert.assertEquals(Null_Val.trim(), ErrStr.trim());
//  }
  
  @Test
  public void Count_Link_Test() throws InterruptedException {
	  sd2l1.init(driver);
	  List cnt = sd2l1.Count_Links();
//	  System.out.print("Total no of links is :"+ cnt);
	  Assert.assertEquals(Dum_List, cnt);
  }
  
}
