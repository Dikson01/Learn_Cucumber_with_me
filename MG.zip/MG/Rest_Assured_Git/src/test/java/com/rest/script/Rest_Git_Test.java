package com.rest.script;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.rest.code.Rest_Git;

public class Rest_Git_Test {

	   String token = "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";
	   String endP = "/users/Dikson01/repos";
	   String endP_Post = "/user/repos";
	   String endP_Dele = "/repos/Dikson01/restassured_demo_test01"; //using the repo that we just create now
	   String body = "{"
			   + "\"name\": \"restassured_demo_test01\","
			   + "\"description\": \"Created using GitHub rest api\"," 
			   + "\"private\": false" 
			   + "}";

	    @Test
	    public void verifyGitHubReposAPI() {

	        Rest_Git lib = new Rest_Git();

	        String statusLine = lib.getStatusLine(token, endP);
	        int statusCode = lib.getStatusCode(token, endP);

	        System.out.println(statusLine);
	        System.out.println(statusCode);

	        Assert.assertTrue(statusLine.contains("200"), "Status line validation");
	        Assert.assertEquals(statusCode, 200, "Status code validation");
	        
//	        int postCode = lib.postStatusCode(token, endP_Post, body);
//	        System.out.println("POST status code: "+ postCode);
//	        Assert.assertEquals(postCode, 201, "Create repo should return 201");
	        
//	        int DeleteCode = lib.deleteStatusCode(token, endP_Dele);
//	        System.out.println("Deleted status code :" + DeleteCode);
//	        Assert.assertEquals(DeleteCode, 204, "Deleting repo should return 204");

	        
	        
	    }
	     
	    
	}


