package com.rest.code;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class Rest_Git {
	
	public Rest_Git() {
		RestAssured.baseURI = "https://api.github.com";
	}
	

public String getStatusLine(String token, String endP) {
        return RestAssured.given()
                .relaxedHTTPSValidation()
                .header("Authorization", "Bearer " + token)
                .get(endP)
                .statusLine();
    }

    public int getStatusCode(String token, String endP) {
        return RestAssured.given()
                .relaxedHTTPSValidation()
                .header("Authorization", "Bearer " + token)
                .get(endP)
                .statusCode();
    }
    

public String postStatusLine(String token, String endpoint, String jsonBody) {
        return RestAssured.given()
                .relaxedHTTPSValidation()
                .header("Authorization", "Bearer " + token)
                .header("User-Agent", "rest-assured-client")
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .body(jsonBody)
                .post(endpoint)
                .statusLine();
    }

    public int postStatusCode(String token, String endpoint, String jsonBody) {
        return RestAssured.given()
                .relaxedHTTPSValidation()
                .header("Authorization", "Bearer " + token)
                .header("User-Agent", "rest-assured-client")
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .body(jsonBody)
                .post(endpoint)
                .statusCode();
    }
    
    public int deleteStatusCode(String token, String endP) {
    	return RestAssured.given()
    			.relaxedHTTPSValidation()
    			.header("Authorization", "Bearer " + token)
    			.header("User-Agent", "rest-assured-client")
    			.delete(endP)
    			.statusCode();
    }

	
	
}
