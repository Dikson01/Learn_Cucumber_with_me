package com.Sele4_2.Test;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.Sele_d4_2.Base1;
import com.Sele_d4_2.Lib1;

public class test_all_proccess extends Base1 {
	
//   @DataProvider
//   public Object[][] data() {
//	   return new Object[][] {
//		   {"ajkfd"},{"gsadg"}
//	   };
//   }	
//	
  @Test
  public void Test_all() {
	  Lib1 l1 = new Lib1();
	  l1.openUrl("https://katalon-demo-cura.herokuapp.com");
	  l1.openBestSeller();
  }
}
