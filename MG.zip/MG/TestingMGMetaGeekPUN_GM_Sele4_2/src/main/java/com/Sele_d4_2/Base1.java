package com.Sele_d4_2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;

public class Base1 {
	
	public static WebDriver driver;
	
	@BeforeTest
	public void setUp() throws InterruptedException {
		driver = new EdgeDriver();
		driver.manage().window().maximize();
		Thread.sleep(2000);
	}
//	@AfterClass
//	public void tearDown() {
//		driver.close();
//	}
	
}
