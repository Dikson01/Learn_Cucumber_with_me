package com.Sele_d4_2;

public class Lib2 extends Base1 {
	
	
}
