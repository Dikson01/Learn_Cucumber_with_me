package com.Sele_d4_2;

import org.openqa.selenium.By;

public class Lib1 extends Base1 {
	
	public void openUrl(String url) {
		driver.get(url);
	}
	public void openBestSeller() {
		driver.findElement(By.xpath("//*[@id=\"btn-make-appointment\"]")).click(); 
		//driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[2]/a")).click();
	}
	
}
