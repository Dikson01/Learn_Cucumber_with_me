package com.read_data;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import com.data_driven.Excel_Reader1;

public class Read_Excel {
	Excel_Reader1 ex1 = new Excel_Reader1();
	WebDriver driver = new EdgeDriver();
	
  @Test
  public void Read_data() throws IOException {
	  
	  ex1.init(driver);
	  String res = ex1.Read_Data(1, 1);
	  System.out.println(res);
	  
	  
  }
}
