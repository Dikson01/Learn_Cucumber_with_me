package TestingMGMetaGeekPUN_GM_Sele4_DataDriven.TestingMGMetaGeekPUN_GM_Sele4_DataDriven;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
