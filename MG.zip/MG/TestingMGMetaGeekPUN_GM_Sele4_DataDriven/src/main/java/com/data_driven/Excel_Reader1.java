package com.data_driven;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Excel_Reader1 {
	WebDriver driver;
	
	public void init(WebDriver driver) {
		this.driver = driver;
	}
	
	public String Read_Data(int vRow, int vColumn) throws IOException {
		String value = null;
		Workbook wb = null;
		
		
		//read data from excel in form of bytes
		FileInputStream fis = new FileInputStream("./Teast_Data/Book1.xlsx");
		//constructs an XSSFWorkbook object, by buffering the whole stream into the memory
		wb = new XSSFWorkbook(fis);
		
		//wb.getsh
		Sheet sheet = wb.getSheetAt(0);  //getting the XSSFSheet object at given index
		Row row = sheet.getRow(vRow);   //return the logical row 
		Cell cell = row.getCell(vColumn);  //getting the cell representing the given column
		value = cell.getStringCellValue();  //getting the cell value
		
		driver.get("https://google.com/");
		driver.findElement(By.xpath("//*[@id='APjFqb']")).sendKeys(value);
		driver.findElement(By.xpath("//*[@id='APjFqb']")).submit();
		
		
		return value;						//returning the cell value
		
		
	}
	
}
