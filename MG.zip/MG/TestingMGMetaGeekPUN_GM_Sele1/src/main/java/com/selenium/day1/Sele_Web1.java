package com.selenium.day1;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Sele_Web1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver wd = new EdgeDriver();
		wd.get("https://www.awesomeqa.com/ui");
		
		
		
	}

}
