package com.selenium.day1;

import org.openqa.selenium.WebDriver;

public class Sele_Web_lib2 {
	
	WebDriver driver;
	
	public void init0(WebDriver driver) {
		this.driver=driver;
	}
	
	//Maximize the browser window
	public void Maximize_Browser_Window() {
		driver.manage().window().maximize();
	}
	
	public void Dele_Cookeies() {
		driver.manage().deleteAllCookies();
	}
	
	public void Navigate_Back() {
		driver.navigate().back();
	}
	
	public void Navigate_refresh() {
		driver.navigate().refresh();
	}
	
	public String Extract_PageSource() {
		return driver.getPageSource();
	}

}
