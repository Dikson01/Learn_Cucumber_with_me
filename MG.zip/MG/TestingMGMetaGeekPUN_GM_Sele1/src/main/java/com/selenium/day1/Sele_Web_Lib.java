package com.selenium.day1;

import org.openqa.selenium.WebDriver;

public class Sele_Web_Lib {
	
	WebDriver driver;
	public void init(WebDriver driver) {
		this.driver=driver;
	}
	
	public void InvokeAwesomeQaApp() {
		driver.get("https://www.awesomeqa.com/ui");
	}
	
	public String AwesomeHome_PageTitle() {
		String pgTitleHome=driver.getTitle();
		return pgTitleHome;

	}
	
}
