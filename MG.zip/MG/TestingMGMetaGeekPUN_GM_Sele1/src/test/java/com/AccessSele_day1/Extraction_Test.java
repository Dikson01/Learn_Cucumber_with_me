package com.AccessSele_day1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import com.selenium.day1.Sele_Web_Lib;
import com.selenium.day1.Sele_Web_lib2;

public class Extraction_Test {
	//create the browser browser instance
		WebDriver driver = new EdgeDriver();
		//Object for Lib class
		Sele_Web_Lib pg1 = new Sele_Web_Lib();
		Sele_Web_lib2 pg2 = new Sele_Web_lib2();
	
	
  @Test
  public void Extract_Page_Content() {
	  pg1.init(driver);
	  pg1.InvokeAwesomeQaApp();
	  
	  pg2.init0(driver);
	  String pgsource = pg2.Extract_PageSource();
	  System.out.println(pgsource);
  }
}
