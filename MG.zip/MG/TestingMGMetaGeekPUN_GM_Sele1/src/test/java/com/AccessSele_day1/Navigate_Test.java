package com.AccessSele_day1;

import org.openqa.selenium.*;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;


import com.selenium.day1.Sele_Web_Lib;
import com.selenium.day1.Sele_Web_lib2;

public class Navigate_Test {
	
	WebDriver driver = new EdgeDriver();
	//Object
	Sele_Web_Lib pg1 = new Sele_Web_Lib();
	Sele_Web_lib2 pg2 = new Sele_Web_lib2();
	
  @Test
  public void NavigateBackTest() throws InterruptedException {
	  pg1.init(driver);
	  pg1.InvokeAwesomeQaApp();
	  
	  pg2.init0(driver);
	  Thread.sleep(5000);
	  pg2.Navigate_Back();
	  
  }
}
