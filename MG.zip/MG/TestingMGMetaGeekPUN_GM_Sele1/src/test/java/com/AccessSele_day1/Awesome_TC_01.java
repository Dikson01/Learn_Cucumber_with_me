package com.AccessSele_day1;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import com.selenium.day1.Sele_Web_Lib;
import com.selenium.day1.Sele_Web_lib2;

import junit.framework.Assert;

public class Awesome_TC_01 {
	//create the browser browser instance
	WebDriver driver = new EdgeDriver();
	//Object for Lib class
	Sele_Web_Lib pg1 = new Sele_Web_Lib();
	Sele_Web_lib2 pg2 = new Sele_Web_lib2();
	
	String Expected_Pg_Title = "Your Store";
	
  @Test(priority = 1)
  public void InvokeApp_Awesome() {
	  pg1.init(driver);
	  pg1.InvokeAwesomeQaApp();
	  
	  String HomePgTitleIs = pg1.AwesomeHome_PageTitle();
	  System.out.println("HomePgTitleIs" + " " + HomePgTitleIs);
	  
	  Assert.assertEquals(HomePgTitleIs, Expected_Pg_Title);
	  
  }
  @Test(priority = 2)
  public void Assertion_Awesome() {

  pg2.init0(driver);
  pg2.Maximize_Browser_Window();
  pg2.Dele_Cookeies();
  
  }
}
