package TestingMGMetaGeekPUN_GM_Sele5_wait.TestingMGMetaGeekPUN_GM_Sele5_wait;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
