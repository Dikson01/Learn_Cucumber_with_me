package com.Login.D3;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Google_Dropdown {
	
	WebDriver driver;
	
	public void init(WebDriver driver) {
		this.driver=driver;
	}
	
	public void OpenUrl() {
		driver.get("https://www.google.com");
	}
	
	public void OpenDropDown() {
		driver.findElement(By.xpath("html/body/div[2]/div[4]/form/div[1]/div[1]/div[1]/div[1]/div[3]/textarea")).click();
//		driver.findElement(By.xpath("html/body/div[2]/div[4]/form/div[1]/div[1]/div[2]/div[4]/div[2]/div[1]/div/ul/li/div/div[2]")).click();
	}
	
	public int Count_Links() throws InterruptedException {
		Thread.sleep(1000);
		List <WebElement> C_Links = driver.findElements(By.xpath("html/body/div[2]/div[4]/form/div[1]/div[1]/div[2]/div[4]/div[2]/div[1]/div/ul/li"));
		int LinkCounts = C_Links.size();
		return LinkCounts;
	}
	
	public List Link_Name() throws InterruptedException {
		Thread.sleep(2000);
		List <WebElement> Links_N = driver.findElements(By.xpath("html/body/div[2]/div[4]/form/div[1]/div[1]/div[2]/div[4]/div[2]/div[1]/div/ul/li"));
		int LinkCounts = Links_N.size();
		
		Thread.sleep(2000);
		for (int i=0; i<LinkCounts; i++) {
			String Link_Name = Links_N.get(i).getText();
			Thread.sleep(200);
			System.out.println(Link_Name);
		}
		
		return Links_N;
	}
	
	public void Open3Link() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.xpath("html/body/div[2]/div[4]/form/div[1]/div[1]/div[2]/div[4]/div[2]/div[1]/div/ul/li[3]/div/div[2]")).click();
	}
}
