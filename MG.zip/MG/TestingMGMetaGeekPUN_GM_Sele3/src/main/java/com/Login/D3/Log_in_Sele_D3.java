package com.Login.D3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Log_in_Sele_D3 {
	
	WebDriver driver;
	
	public void init(WebDriver driver) {
		this.driver = driver;
	}
	
	public void Invoke_Page() {
		driver.get("https://awesomeqa.com/ui/index.php?route=account/login");
	}
	
	public void Log_out() {
		driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a")).click();
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/ul/li[5]/a")).click();
	}
	
	public String Perform_Login_Valid(String email, String password) throws InterruptedException {
		driver.findElement(By.xpath("//input[@id = \"input-email\"]")).sendKeys(email);
		driver.findElement(By.xpath("//input[@id = \"input-password\"]")).sendKeys(password);
		driver.findElement(By.xpath("//input[@type = \"submit\"]")).click();
		Thread.sleep(3000);
		String msg = driver.findElement(By.xpath("//div[@id = 'content']//h2[2]")).getText();
		return msg;
	}
	
	
	public String Invalid_Null_Login(String email, String password) throws InterruptedException {
		driver.findElement(By.xpath("//input[@id = \"input-email\"]")).sendKeys(email);
		driver.findElement(By.xpath("//input[@id = \"input-password\"]")).sendKeys(password);
		driver.findElement(By.xpath("//input[@type = \"submit\"]")).click();
		Thread.sleep(3000);
		String Error_msg = driver.findElement(By.xpath("//div[@id = 'content']//h2[2]")).getText();
		return Error_msg;
	}
}
