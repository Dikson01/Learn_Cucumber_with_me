package com.Login.D3;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Table_Scraping {

	WebDriver driver;
	
	public void init(WebDriver driver) {
		this.driver=driver;
	}
	
	public void OpenUrl() {
		driver.get("https://www.w3schools.com/html/html_tables.asp");
	}
	
	public void Table_head() {
		String head = driver.findElement(By.xpath("//*[@id=\"customers\"]//tr[1]//th[2]")).getText();
		System.out.println(head);
	} 
	
	public void Table_Data() throws InterruptedException {
		Thread.sleep(2000);
		List <WebElement> Tb_Data = driver.findElements(By.xpath("//*[@id='customers']//tr//td[2]"));
		int count = Tb_Data.size();
		
		for(int i=0; i<count; i++) {
			String Data = Tb_Data.get(i).getText();
			System.out.println("Data on this column are : "+Data);
		}
	}
}
