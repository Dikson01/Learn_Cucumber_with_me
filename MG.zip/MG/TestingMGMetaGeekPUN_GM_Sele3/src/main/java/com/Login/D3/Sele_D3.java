package com.Login.D3;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class Sele_D3 {
	
	WebDriver driver;
	public void init(WebDriver driver) {
		this.driver=driver;
	}
	public void Drop_check() throws InterruptedException {
		driver.get("https://www.amazon.in/");
		Thread.sleep(2000);
		WebElement DropDown = driver.findElement(By.xpath("//select[@id='searchDropdownBox']"));
		Select select = new Select(DropDown);
		List <WebElement> allOptions = select.getOptions();
		int optionCount = allOptions.size();
		System.out.println(optionCount);
		
		for(int i=0; i<optionCount; i++) {
			String x = allOptions.get(i).getText();
			System.out.println(x);
		}
		
		Thread.sleep(2000);
		select.selectByValue("search-alias=amazon-devices");
//		This will not work as amazon don't allow to inspect the options of select
//		driver.findElement(By.xpath("//select[@id='searchDropdownBox']")).click();
//		Thread.sleep(2000);
//		select.selectByVisibleText("Baby");
	}
	
	
	//Alert Test.
	public String Alert_Msg() throws InterruptedException {
		driver.get("https://mail.rediff.com/cgi-bin/login.cgi");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@name = 'proceed']")).click();
		Thread.sleep(2000);
		Alert alt = driver.switchTo().alert();
		Thread.sleep(2000);
		String alt_msg = alt.getText();
		Thread.sleep(2000);
		alt.accept();
		return alt_msg;
		
	}
	
}

























