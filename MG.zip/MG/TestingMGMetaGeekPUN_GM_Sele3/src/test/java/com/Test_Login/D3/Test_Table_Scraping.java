package com.Test_Login.D3;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import com.Login.D3.Google_Dropdown;
import com.Login.D3.Table_Scraping;

public class Test_Table_Scraping {
	
	WebDriver driver = new EdgeDriver();
	Table_Scraping gd1 = new Table_Scraping();
	
  @Test
  public void Test_Table() throws InterruptedException {
	  gd1.init(driver);
	  gd1.OpenUrl();
	  gd1.Table_head();
	  gd1.Table_Data();
  }
}
