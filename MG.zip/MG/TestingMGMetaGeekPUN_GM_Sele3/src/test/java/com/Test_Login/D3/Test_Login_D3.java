package com.Test_Login.D3;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.Login.D3.Log_in_Sele_D3;

import junit.framework.Assert;

public class Test_Login_D3 {
	

	@DataProvider(name = "loginData")
    public Object[][] loginData() {
        return new Object[][]{
                {"user1", "pass1", true},   // valid
                {"user2", "pass2", true},   // valid
                {"user3", "wrong", false}   // invalid
        };
	}

	WebDriver driver = new EdgeDriver();
	
	Log_in_Sele_D3 obj1 = new Log_in_Sele_D3();
	
	String ExpStr = "My Orders";
	String ErrStr = " Warning: Your account has exceeded allowed number of login attempts. Please try again in 1 hour.";
	
  @Test(priority = 1)
  public void Test1() throws InterruptedException {
	  obj1.init(driver);
	  obj1.Invoke_Page();
	  String ActStr = obj1.Perform_Login_Valid("gayatrimis2@gmail.com", "gayatrimis2@gmail.com");
	  Assert.assertEquals(ExpStr, ActStr);
	  obj1.Log_out();
  }
  
  @Test(priority = 2)
  public void Test2() throws InterruptedException {
	  obj1.init(driver);
	  obj1.Invoke_Page();
	  String Null_Val = obj1.Invalid_Null_Login("dzfhgx","hxdhgx");
	  Assert.assertEquals(Null_Val.trim(), ErrStr.trim());
  }
}
