package com.Test_Login.D3;

import org.testng.annotations.Test;

import com.Login.D3.Sele_D3;

import junit.framework.Assert;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Sele_D3_Test {
	WebDriver driver = new EdgeDriver();
	Sele_D3 d1 = new Sele_D3();
	String Exp_Alt_Msg = "Please enter a valid user name";
	
	
  @Test
  public void Test_Drop() throws InterruptedException {
	  d1.init(driver);
	  d1.Drop_check();
  }
  
  
  @Test
  public void Test_Alert() throws InterruptedException {
	  d1.init(driver);
	  Thread.sleep(2000);
	  String Actual_Alt_Msg = d1.Alert_Msg();
	  Thread.sleep(2000);
	  Assert.assertEquals(Actual_Alt_Msg, Exp_Alt_Msg);
  }
  
  
}
