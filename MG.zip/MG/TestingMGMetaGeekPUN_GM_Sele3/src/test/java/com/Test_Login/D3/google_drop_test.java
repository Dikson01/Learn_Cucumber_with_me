package com.Test_Login.D3;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import com.Login.D3.Google_Dropdown;

public class google_drop_test {
	
	WebDriver driver = new EdgeDriver();
	Google_Dropdown gd1 = new Google_Dropdown();

	
  @Test
  public void Test1() throws InterruptedException {
	  
	  gd1.init(driver);
	  gd1.OpenUrl();
	  gd1.OpenDropDown();
	  int Links = gd1.Count_Links();
	  System.out.println("The no. of total Links is " + Links);
	  gd1.Link_Name();
	  gd1.Open3Link();
  }
  
  
  
  ///html/body/div[2]/div[4]/form/div[1]/div[1]/div[1]/div[1]/div[3]/textarea
  ///html/body/div[2]/div[4]/form/div[1]/div[1]/div[2]/div[4]/div[2]/div[1]/div/ul/li/div/div[2]
}
